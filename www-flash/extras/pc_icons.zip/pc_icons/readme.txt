City Creator Icons.
�Copyright 2002 Denise Wilton (Converted to PC format by Cal)

These icons were created for City Creator (www.citycreator.com) a site made 
by Denise Wilton and Cal Henderson. They are free for personal use only. If 
you'd like to use these icons for your online site, then please email 
planning@citycreator.com and let us now - it's nice to see where things end 
up!

Thanks for dropping by,
The City Creator Team.

\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:\:

Using icons in windows

Right-click on your desktop and choose "Properties" from the menu. This 
should pop up the "Display Properties" window. Click on the "Desktop" tab, 
then the "Customize Desktop..." button. In the new dialog that appears, 
you can choose an icon to customise - click on the icon then click on the 
"Change Icon..." button. Browse to where the icons are and select the one 
you want to use. Now click "OK" to save your changes.
